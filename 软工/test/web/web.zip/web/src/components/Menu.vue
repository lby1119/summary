<template>
    <div>
        <!-- 面包屑导航区域 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>菜单管理</el-breadcrumb-item>
        </el-breadcrumb>
        <el-row>
            <el-col :span="12"><div>
                <el-table
    :data="tableData"
    height="250"
    style="width: 100%;height: 100vh">
    <el-table-column type="expand">
      <template slot-scope="props">
        <el-form label-position="left" inline class="demo-table-expand">
          <el-form-item label="商品名称">
            <span>{{ props.row.name }}</span>
          </el-form-item>
          <el-form-item label="商品 ID">
            <span>{{ props.row.id }}</span>
          </el-form-item>
          <el-form-item label="商品分类">
            <span>{{ props.row.category }}</span>
          </el-form-item>
          <el-form-item label="商品描述">
            <span>{{ props.row.desc }}</span>
          </el-form-item>
        </el-form>
      </template>
    </el-table-column>
    <el-table-column
      label="菜品 ID"
      prop="id">
    </el-table-column>
    <el-table-column
      label="菜品名称"
      prop="name">
    </el-table-column>
    <el-table-column
      label="菜品分类"
      prop="category">
    </el-table-column>
    <el-table-column
      label="菜品描述"
      prop="desc">
    </el-table-column>
    <el-table-column
      align="right">
      <template slot="header">
          <el-input v-model="input" placeholder="请输入内容">
            <i slot="prefix" class="el-input__icon el-icon-search"></i>
            <el-button slot="append" icon="el-icon-search"></el-button>
          </el-input>
      </template>
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="handleEdit(scope.$index, tableData)">Edit</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="deleteRow(scope.$index, tableData)">Delete</el-button>
      </template>
    </el-table-column>
  </el-table>
                </div>
            </el-col>
            <el-col :span="12"><div>
                
                </div>
            </el-col>
        </el-row>
        <el-row>
          <el-col :span="12" style="text-align: right">
          <el-button type="primary" @click="addDialogVisible = true">添加菜品</el-button>
        </el-col>
        </el-row>
        
    </div>
</template>

<script>
  export default {
    data() {
      return {
                input:"",
        tableData: [
          {
          id: '1',
          name: '好滋好味鸡蛋仔',
          category: '江浙小吃、小吃零食',
          desc: '荷兰优质淡奶，奶香浓而不腻',
          address: '上海市普陀区真北路',
          shop: '王小虎夫妻店',
          shopId: '10333'
        },
        {
          id: '12987123',
          name: '好滋好味鸡蛋仔',
          category: '小食',
          desc: '荷兰优质淡奶，奶香浓而不腻',
          address: '上海市普陀区真北路',
          shop: '王小虎夫妻店',
          shopId: '10332'
        }
        ],
      }
    },
    methods: {
      handleEdit(index, row) {
        console.log(index, row);
      },
      deleteRow(index, rows) {
        rows.splice(index, 1);
      }
    },
  }
</script>

<style>
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>








