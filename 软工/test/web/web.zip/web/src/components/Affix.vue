<template>
  <el-affix >
    <el-button type="primary">
      <h1>餐厅智能化管理软件</h1>
    </el-button>
  </el-affix>
</template>

<script>
export default {
  name: "Affix"
}
</script>

<style scoped>



</style>